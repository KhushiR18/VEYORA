# Veyora: test checklist and demo script

## Quick test (5 minutes, run before every demo)
1. Open the page. Header shows the pin logo; tab shows the favicon.
2. Search "Goa": cards show; sort by price and by rating works.
3. Filters: set Min rating 4.5+, tick Pool, move Max price. Cards update; Reset restores them.
4. Quick starts: tap "Honeymoon". SmartMatch runs, cards show "% match" with reasons.
5. Compare: tick 3 hotels. The bar appears; a 4th tick is refused. Open Compare and check the table.
6. Details: scores show. Heart a hotel, refresh the page, the heart is still there.
7. Preferences (nav): change bed and tick Vegetarian, Save. Open a booking: they are pre-filled.
8. Booking: Continue to payment. Try a wrong UPI ID (error), then name@bank (works).
9. Confirmation: step 3 shows. Print confirmation opens the print view. View my trips lists it.
10. Cancel the stay in My trips. Sign in, sign out: only one popup appears.
11. Resize to phone width: menu button, cards and modals still fit.

## Demo script (about 3 minutes)
- "Veyora is a booking app built around the guest, not the hotel list."
- Set preferences once (Preferences). "Every booking starts from these."
- Tap a Quick start. "SmartMatch ranks stays and tells you why."
- Compare two hotels. Open one: "guest scores are sample data for the demo."
- Book it: choose extras, pay with a demo UPI ID, show the confirmation and My trips.
- Close with: "All data calls go through api.js, so the Java backend plugs in by setting one URL."

## Honest notes for questions
- Rates, ratings, scores and availability are sample data. No real payment is taken or stored.
- Data is saved in the browser (localStorage) until the backend is connected.

'use strict';
// VEYORA student demo: real hotel names, illustrative prices, no live inventory or reservations.

const photo = {
    coast: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1000&q=85',
    hotel: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1000&q=85',
    room: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1000&q=85',
    garden: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1000&q=85',
    mountain: 'https://images.unsplash.com/photo-1518732714860-b62714ce0c59?auto=format&fit=crop&w=1000&q=85'
};

const hotels = [
    {
        id: 'taj-fort',
        name: 'Taj Fort Aguada Resort & Spa, Goa',
        area: 'Sinquerim, Candolim, Goa',
        region: 'Goa',
        price: 18500,
        rating: 4.8,
        badge: 'ICONIC ESCAPE',
        image: 'https://images.luxuryescapes.com/fl_progressive%2Cq_auto%3Agood/8mo6lii57aenfjscwmu',
        description: 'A classic seaside retreat with lush gardens, ocean views and a relaxed luxury feel.',
        features: ['Sea views', 'Swimming pool', 'Spa', 'Restaurant'],
        amenities: ['pool', 'beach', 'spa', 'breakfast'],
        mood: ['Luxury', 'Quiet', 'Romantic'],
        purpose: ['Leisure', 'Romantic', 'Family'],
        roomTypes: ['Deluxe', 'Suite', 'Villa'],
        areas: ['candolim', 'sinquerim', 'baga', 'goa']
    },
    {
        id: 'marriott-goa',
        name: 'Goa Marriott Resort & Spa',
        area: 'Miramar, Panaji, Goa',
        region: 'Goa',
        price: 16200,
        rating: 4.7,
        badge: 'WATERFRONT FAVOURITE',
        image: 'https://pix10.agoda.net/hotelImages/8726/-1/a5fad14c3c4efc1332a2287fdeb23458.jpg?ce=0&s=1024x768',
        description: 'A waterfront resort close to the city, with a pool, spa and easy access to Panaji.',
        features: ['Waterfront', 'Swimming pool', 'Spa', 'Breakfast'],
        amenities: ['pool', 'spa', 'breakfast'],
        mood: ['Luxury', 'Lively'],
        purpose: ['Leisure', 'Business', 'Family', 'Romantic'],
        roomTypes: ['Deluxe', 'Suite'],
        areas: ['panaji', 'miramar', 'goa']
    },
    {
        id: 'alila-diwa',
        name: 'Alila Diwa Goa',
        area: 'Majorda, South Goa',
        region: 'Goa',
        price: 14500,
        rating: 4.7,
        badge: 'SLOW-DOWN SPOT',
        image: 'https://assets.hyatt.com/content/dam/hyatt/hyattdam/images/2019/07/08/1635/Alila-Diwa-Goa-P030-Two-Twin-Beds-Family-Terrace-Room.jpg/Alila-Diwa-Goa-P030-Two-Twin-Beds-Family-Terrace-Room.16x9.jpg?imwidth=1280',
        description: 'A tranquil resort framed by tropical greenery, made for slower days and restorative breaks.',
        features: ['Infinity pool', 'Spa', 'Garden views', 'Dining'],
        amenities: ['pool', 'spa', 'breakfast'],
        mood: ['Quiet', 'Luxury', 'Romantic'],
        purpose: ['Leisure', 'Romantic', 'Family'],
        roomTypes: ['Deluxe', 'Suite'],
        areas: ['majorda', 'south goa', 'benaulim', 'varca', 'goa']
    },
    {
        id: 'hyatt-candolim',
        name: 'Hyatt Place Goa Candolim',
        area: 'Candolim, North Goa',
        region: 'Goa',
        price: 9200,
        rating: 4.4,
        badge: 'NORTH GOA BASE',
        image: 'https://dynamic-media-cdn.tripadvisor.com/media/photo-o/31/a2/84/41/room-view.jpg?h=-1&s=1&w=1200',
        description: 'A comfortable base for exploring North Goa, with contemporary rooms and easy-going amenities.',
        features: ['Swimming pool', 'Breakfast', 'Fitness centre', 'Wi-Fi'],
        amenities: ['pool', 'breakfast'],
        mood: ['Lively'],
        purpose: ['Leisure', 'Business', 'Family'],
        roomTypes: ['Standard', 'Deluxe'],
        areas: ['candolim', 'calangute', 'baga', 'goa']
    },
    {
        id: 'st-regis-goa',
        name: 'The St. Regis Goa Resort',
        area: 'Mobor, South Goa',
        region: 'Goa',
        price: 22500,
        rating: 4.8,
        badge: 'SPECIAL OCCASIONS',
        image: 'https://www.cvent.com/venues/_next/image?q=75&url=https%3A%2F%2Fimages.cvent.com%2Fcsn%2F5938eca4-e431-49fe-a80e-0d447433860f%2Fimages%2Fc8114aa09e7d498ea0facaf7386f811b_large%21_%214245636c30027d6874948a999bd56f5e.jpg&w=3840',
        description: 'A polished luxury escape in South Goa with expansive grounds and a serene resort atmosphere.',
        features: ['Pool', 'Spa', 'Beach nearby', 'Fine dining'],
        amenities: ['pool', 'beach', 'spa', 'breakfast'],
        mood: ['Luxury', 'Quiet', 'Romantic'],
        purpose: ['Leisure', 'Romantic', 'Family'],
        roomTypes: ['Deluxe', 'Suite', 'Villa'],
        areas: ['mobor', 'south goa', 'varca', 'goa']
    },
    {
        id: 'taj-west-end',
        name: 'Taj West End, Bengaluru',
        area: 'Race Course Road, Bengaluru, Karnataka',
        region: 'Bengaluru',
        price: 16500,
        rating: 4.7,
        badge: 'GARDEN CITY CLASSIC',
        image: 'https://cdn.sanity.io/images/ocl5w36p/production/fca3fe1c05cb133cb21e9284aa9a4f33d94d49a9-1401x1121.jpg?auto=format&dpr=2&w=480',
        description: 'A heritage luxury hotel set amid landscaped gardens in the heart of Bengaluru.',
        features: ['Garden setting', 'Pool', 'Spa', 'Fine dining'],
        amenities: ['pool', 'spa', 'breakfast'],
        mood: ['Quiet', 'Luxury'],
        purpose: ['Leisure', 'Business', 'Romantic'],
        roomTypes: ['Deluxe', 'Suite'],
        areas: ['bengaluru', 'bangalore', 'karnataka']
    },
    {
        id: 'leela-bengaluru',
        name: 'The Leela Palace Bengaluru',
        area: 'Old Airport Road, Bengaluru, Karnataka',
        region: 'Bengaluru',
        price: 21000,
        rating: 4.8,
        badge: 'PALACE LUXURY',
        image: 'https://images.trvl-media.com/lodging/1000000/860000/851500/851448/bcce7152.jpg?h=800&impolicy=fcrop&quality=medium&w=1200',
        description: 'A palace-inspired city hotel with ornate architecture, polished service and elegant rooms.',
        features: ['Luxury spa', 'Pool', 'Restaurants', 'Fitness centre'],
        amenities: ['pool', 'spa', 'breakfast'],
        mood: ['Luxury', 'Quiet'],
        purpose: ['Business', 'Leisure', 'Romantic'],
        roomTypes: ['Deluxe', 'Suite'],
        areas: ['bengaluru', 'bangalore', 'karnataka']
    },
    {
        id: 'taj-mumbai',
        name: 'The Taj Mahal Palace, Mumbai',
        area: 'Apollo Bunder, Colaba, Mumbai, Maharashtra',
        region: 'Mumbai',
        price: 24500,
        rating: 4.8,
        badge: 'ICONIC LANDMARK',
        image: 'https://images.trvl-media.com/lodging/20000000/19460000/19458500/19458493/c0b57d04.jpg?h=800&impolicy=fcrop&quality=medium&w=1200',
        description: 'A landmark waterfront hotel overlooking the Gateway of India, rich in history and character.',
        features: ['Harbour views', 'Pool', 'Spa', 'Fine dining'],
        amenities: ['pool', 'spa', 'breakfast'],
        mood: ['Luxury', 'Romantic'],
        purpose: ['Leisure', 'Business', 'Romantic'],
        roomTypes: ['Deluxe', 'Suite'],
        areas: ['mumbai', 'bombay', 'maharashtra']
    },
    {
        id: 'trident-mumbai',
        name: 'Trident, Nariman Point, Mumbai',
        area: 'Nariman Point, Mumbai, Maharashtra',
        region: 'Mumbai',
        price: 15500,
        rating: 4.6,
        badge: 'SEA-VIEW CITY STAY',
        image: 'https://r1imghtlak.ibcdn.com/644b5146236f11e8a52d025f77df004f.jpg',
        description: 'A polished city hotel with Arabian Sea views and easy access to South Mumbai business and culture.',
        features: ['Sea views', 'Pool', 'Restaurants', 'Business facilities'],
        amenities: ['pool', 'breakfast'],
        mood: ['Lively', 'Luxury'],
        purpose: ['Business', 'Leisure'],
        roomTypes: ['Deluxe', 'Suite'],
        areas: ['mumbai', 'bombay', 'maharashtra']
    },
    {
        id: 'imperial-delhi',
        name: 'The Imperial, New Delhi',
        area: 'Janpath, New Delhi, Delhi',
        region: 'Delhi',
        price: 23000,
        rating: 4.8,
        badge: 'TIMELESS GRANDEUR',
        image: 'https://assets.blupp.co/5eab48e5-0d42-4c6e-bc72-b1b5462d2795/2126c187-7b67-411f-8bd9-57d5c23b6669/b37bc4a7-f8b2-4a68-b4ff-784b526bd80d/grand-heritage-room_cover.jpg?quality=80&width=1000',
        description: 'A storied luxury hotel with elegant architecture, gardens and a central New Delhi address.',
        features: ['Heritage interiors', 'Pool', 'Spa', 'Fine dining'],
        amenities: ['pool', 'spa', 'breakfast'],
        mood: ['Luxury', 'Quiet', 'Romantic'],
        purpose: ['Business', 'Leisure', 'Romantic'],
        roomTypes: ['Deluxe', 'Suite'],
        areas: ['delhi', 'new delhi', 'ncr']
    },
    {
        id: 'rambagh-jaipur',
        name: 'Rambagh Palace, Jaipur',
        area: 'Bhawani Singh Road, Jaipur, Rajasthan',
        region: 'Jaipur',
        price: 32000,
        rating: 4.9,
        badge: 'ROYAL RETREAT',
        image: 'https://media.easemytrip.com/media/Hotel/SHL-230822882415245/RoomImage/RoomImage6DQqu8.jpg',
        description: 'A former royal residence with manicured gardens, grand interiors and a memorable palace atmosphere.',
        features: ['Palace setting', 'Pool', 'Spa', 'Fine dining'],
        amenities: ['pool', 'spa', 'breakfast'],
        mood: ['Luxury', 'Quiet', 'Romantic'],
        purpose: ['Leisure', 'Romantic', 'Family'],
        roomTypes: ['Suite', 'Villa'],
        areas: ['jaipur', 'rajasthan']
    },
    {
        id: 'taj-udaipur',
        name: 'Taj Lake Palace, Udaipur',
        area: 'Lake Pichola, Udaipur, Rajasthan',
        region: 'Udaipur',
        price: 38500,
        rating: 4.9,
        badge: 'LAKE PALACE DREAM',
        image: 'https://images.trvl-media.com/lodging/1000000/530000/526400/526333/cc614057.jpg?impolicy=resizecrop&ra=fill&rh=575&rw=575',
        description: 'A celebrated white palace hotel on Lake Pichola, ideal for a memorable romantic escape.',
        features: ['Lake views', 'Boat arrival', 'Spa', 'Fine dining'],
        amenities: ['spa', 'breakfast'],
        mood: ['Luxury', 'Quiet', 'Romantic'],
        purpose: ['Leisure', 'Romantic'],
        roomTypes: ['Suite'],
        areas: ['udaipur', 'rajasthan']
    },
    {
        id: 'grand-hyatt-kochi',
        name: 'Grand Hyatt Kochi Bolgatty',
        area: 'Bolgatty Island, Kochi, Kerala',
        region: 'Kochi',
        price: 15500,
        rating: 4.7,
        badge: 'BACKWATER VIEWS',
        image: 'https://www.kayak.sg/rimg/himg/72/8b/3a/ice-110342-62467110_3XL-455229.jpg?crop=true&height=607&width=836',
        description: 'A waterfront luxury hotel on Bolgatty Island with backwater views, pools and spacious rooms.',
        features: ['Backwater views', 'Pool', 'Spa', 'Restaurants'],
        amenities: ['pool', 'spa', 'breakfast'],
        mood: ['Luxury', 'Quiet'],
        purpose: ['Business', 'Leisure', 'Family'],
        roomTypes: ['Deluxe', 'Suite', 'Family'],
        areas: ['kochi', 'cochin', 'kerala']
    },
    {
        id: 'taj-chennai',
        name: 'Taj Coromandel, Chennai',
        area: 'Nungambakkam, Chennai, Tamil Nadu',
        region: 'Chennai',
        price: 13800,
        rating: 4.6,
        badge: 'CHENNAI CLASSIC',
        image: 'https://cdn.sanity.io/images/ocl5w36p/prod5/a6fe37d6beb0fc0131f3725680b337ed4fb2c258-1400x1120.webp?auto=format&dpr=2&w=480',
        description: 'A classic luxury hotel in central Chennai with refined dining and a convenient business-travel location.',
        features: ['Pool', 'Spa', 'Fine dining', 'Business facilities'],
        amenities: ['pool', 'spa', 'breakfast'],
        mood: ['Luxury', 'Quiet'],
        purpose: ['Business', 'Leisure'],
        roomTypes: ['Deluxe', 'Suite'],
        areas: ['chennai', 'tamil nadu']
    },
    {
        id: 'taj-hyderabad',
        name: 'Taj Falaknuma Palace, Hyderabad',
        area: 'Engine Bowli, Hyderabad, Telangana',
        region: 'Hyderabad',
        price: 35000,
        rating: 4.9,
        badge: 'NIZAM-ERA GRANDEUR',
        image: 'https://travelogyindia.b-cdn.net/travelogyindia-v1/gallery/1735039099-2f33ad50c6e972b2f864a3ad560ccd1ff9bf04df-5227x3433.webp',
        description: 'A restored palace above Hyderabad, offering an atmospheric heritage stay and grand dining spaces.',
        features: ['Palace heritage', 'Fine dining', 'Spa', 'Guided tours'],
        amenities: ['spa', 'breakfast'],
        mood: ['Luxury', 'Quiet', 'Romantic'],
        purpose: ['Leisure', 'Romantic'],
        roomTypes: ['Suite'],
        areas: ['hyderabad', 'telangana']
    },
    {
        id: 'oberoi-agra',
        name: 'The Oberoi Amarvilas, Agra',
        area: 'Taj East Gate Road, Agra, Uttar Pradesh',
        region: 'Agra',
        price: 28500,
        rating: 4.9,
        badge: 'TAJ MAHAL VIEWS',
        image: 'https://www.oberoihotels.com/-/media/oberoi-hotels/website-images/the-oberoi-amarvilas-agra/room-and-suites/room-and-suite-gallery-1448x814/premier-rooms/premier-room-stunning-views-1.jpg',
        description: 'An elegant hotel famed for views towards the Taj Mahal and carefully landscaped grounds.',
        features: ['Taj Mahal views', 'Pool', 'Spa', 'Fine dining'],
        amenities: ['pool', 'spa', 'breakfast'],
        mood: ['Luxury', 'Quiet', 'Romantic'],
        purpose: ['Leisure', 'Romantic', 'Family'],
        roomTypes: ['Deluxe', 'Suite'],
        areas: ['agra', 'uttar pradesh']
    },
    {
        id: 'wildflower-shimla',
        name: 'Wildflower Hall, Shimla',
        area: 'Mashobra, Shimla, Himachal Pradesh',
        region: 'Shimla',
        price: 26000,
        rating: 4.8,
        badge: 'MOUNTAIN HIDEAWAY',
        image: 'https://res.cloudinary.com/purnesh/image/upload/f_auto/v1501229112/wildflower-halll-browse-through-more-images-05.jpg',
        description: 'A mountain retreat surrounded by cedar forests, with Himalayan scenery and a peaceful atmosphere.',
        features: ['Mountain views', 'Pool', 'Spa', 'Nature walks'],
        amenities: ['pool', 'spa', 'breakfast'],
        mood: ['Quiet', 'Luxury', 'Romantic'],
        purpose: ['Leisure', 'Romantic', 'Family'],
        roomTypes: ['Deluxe', 'Suite'],
        areas: ['shimla', 'himachal pradesh']
    },
    {
        id: 'span-manali',
        name: 'Span Resort & Spa, Manali',
        area: 'Kullu-Manali Highway, Manali, Himachal Pradesh',
        region: 'Manali',
        price: 12500,
        rating: 4.6,
        badge: 'RIVERSIDE ESCAPE',
        image: 'https://spanresorts.com/wp-content/uploads/2023/07/span-suite1-1.jpg',
        description: 'A riverside mountain resort with leafy grounds and a restorative setting in the Kullu Valley.',
        features: ['Riverside setting', 'Spa', 'Garden views', 'Restaurant'],
        amenities: ['spa', 'breakfast'],
        mood: ['Quiet', 'Romantic'],
        purpose: ['Leisure', 'Family', 'Romantic'],
        roomTypes: ['Deluxe', 'Suite', 'Family'],
        areas: ['manali', 'himachal pradesh']
    },
    {
        id: 'itc-kolkata',
        name: 'ITC Royal Bengal, Kolkata',
        area: 'EM Bypass, Kolkata, West Bengal',
        region: 'Kolkata',
        price: 14500,
        rating: 4.6,
        badge: 'GRAND CITY ADDRESS',
        image: 'https://cache.marriott.com/content/dam/marriott-renditions/CCULR/cculr-king-guestroom-9248-hor-clsc.jpg?downsize=1336px%3A%2A&interpolation=progressive-bilinear&output-quality=70',
        description: 'A grand contemporary hotel with impressive interiors, multiple restaurants and convenient city access.',
        features: ['Pool', 'Spa', 'Restaurants', 'Business facilities'],
        amenities: ['pool', 'spa', 'breakfast'],
        mood: ['Luxury', 'Lively'],
        purpose: ['Business', 'Leisure', 'Family'],
        roomTypes: ['Deluxe', 'Suite', 'Family'],
        areas: ['kolkata', 'west bengal']
    },
    {
        id: 'taj-varanasi',
        name: 'Taj Ganges, Varanasi',
        area: 'Nadesar, Varanasi, Uttar Pradesh',
        region: 'Varanasi',
        price: 12000,
        rating: 4.5,
        badge: 'CULTURAL CITY STAY',
        image: 'https://cdn.sanity.io/images/ocl5w36p/production/6b7958a5b1138ad9664f7186b1d68573acb0a910-1401x1120.jpg?dpr=2&fm=webp&w=480',
        description: 'A calm garden hotel and comfortable base for exploring the historic city of Varanasi.',
        features: ['Landscaped gardens', 'Pool', 'Restaurant', 'Wellness'],
        amenities: ['pool', 'spa', 'breakfast'],
        mood: ['Quiet'],
        purpose: ['Leisure', 'Family'],
        roomTypes: ['Standard', 'Deluxe', 'Family'],
        areas: ['varanasi', 'uttar pradesh']
    },
    {
        id: 'ibis-bengaluru',
        name: 'ibis Bengaluru City Centre',
        area: 'Richmond Road / Sampangiram Nagar, Bengaluru, Karnataka',
        region: 'Bengaluru',
        price: 6200,
        rating: 4.2,
        badge: 'SMART CITY STAY',
        image: 'https://www.ahstatic.com/photos/6454_roqecef_00_p_1024x768.jpg',
        description: 'A practical city hotel for work trips and short breaks, with compact modern rooms and convenient access to central Bengaluru.',
        features: ['Wi-Fi', 'Restaurant', 'Air conditioning', 'City access'],
        amenities: ['breakfast'],
        mood: ['Lively'],
        purpose: ['Business', 'Leisure'],
        roomTypes: ['Standard', 'Deluxe'],
        areas: ['bengaluru', 'bangalore', 'richmond road', 'sampangiram nagar', 'mg road', 'karnataka']
    },
    {
        id: 'ginger-bengaluru',
        name: 'Ginger Bangalore- Inner Ring Road',
        area: 'Domlur / Inner Ring Road, Bengaluru, Karnataka',
        region: 'Bengaluru',
        price: 4200,
        rating: 4.0,
        badge: 'EVERYDAY COMFORT',
        image: 'https://cdn.sanity.io/images/ocl5w36p/prod5/a51c82602e5bbe83c1f37c9e1e78593a0555c3dd-1016x624.jpg',
        description: 'A no-fuss stay with functional rooms for travellers who want comfort and a sensible nightly rate.',
        features: ['Wi-Fi', 'Air conditioning', 'Restaurant', 'Work desk'],
        amenities: ['breakfast'],
        mood: ['Lively'],
        purpose: ['Business', 'Leisure'],
        roomTypes: ['Standard', 'Deluxe'],
        areas: ['bengaluru', 'bangalore', 'domlur', 'inner ring road', 'indiranagar', 'karnataka']
    },
    {
        id: 'chancery-pavilion',
        name: 'The Chancery Pavilion',
        area: 'Residency Road, Bengaluru, Karnataka',
        region: 'Bengaluru',
        price: 7800,
        rating: 4.2,
        badge: 'CENTRAL CITY BASE',
        image: 'https://r2imghtlak.mmtcdn.com/r2-mmt-htl-image/flyfish/raw/NH2202243918162/QS1042/QS1042-Q1/images.jpeg',
        description: 'A comfortable full-service hotel near central Bengaluru, suitable for business stays and city exploring.',
        features: ['Restaurant', 'Pool', 'Wi-Fi', 'Fitness centre'],
        amenities: ['pool', 'breakfast'],
        mood: ['Lively'],
        purpose: ['Business', 'Leisure', 'Family'],
        roomTypes: ['Standard', 'Deluxe'],
        areas: ['bengaluru', 'bangalore', 'residency road', 'brigade road', 'mg road', 'karnataka']
    },
    {
        id: 'hotel-empire-bengaluru',
        name: 'Hotel Empire International - Church Street',
        area: 'Church Street, Bengaluru, Karnataka',
        region: 'Bengaluru',
        price: 2800,
        rating: 3.8,
        badge: 'BUDGET CITY PICK',
        image: 'https://pix10.agoda.net/property/41508530/1286621319/36413190d4585a71b76ce1170d8fd80c.jpeg?ce=3&s=800x600',
        description: 'A straightforward city stay for guests looking for a basic room, a central location and a more affordable price.',
        features: ['Basic rooms', 'Restaurant nearby', 'Air conditioning', 'Central location'],
        amenities: ['breakfast'],
        mood: ['Lively'],
        purpose: ['Business', 'Leisure'],
        roomTypes: ['Standard'],
        areas: ['bengaluru', 'bangalore', 'church street', 'brigade road', 'mg road', 'commercial street', 'karnataka']
    },
    {
        id: 'bengaluru-basic-inn',
        name: 'Hotel Grand Bee',
        area: 'Yeshwanthpur, Bengaluru, Karnataka',
        region: 'Bengaluru',
        price: 1600,
        rating: 3.6,
        badge: 'BASIC ROOM · BUDGET',
        image: 'https://images.trvl-media.com/lodging/6000000/5630000/5627300/5627211/de831234.jpg?h=800&impolicy=fcrop&quality=medium&w=1200',
        description: 'A practical city hotel with straightforward rooms for short stays near Yeshwanthpur Junction.',
        features: ['Basic private room', 'Fan / AC options', 'Wi-Fi', 'Transit access'],
        amenities: [],
        mood: ['Lively'],
        purpose: ['Business', 'Leisure'],
        roomTypes: ['Basic', 'Standard'],
        areas: ['bengaluru', 'bangalore', 'yeshwanthpur', 'karnataka']
    },
    {
        id: 'koramangala-comfort',
        name: 'Treebo Elite 7',
        area: 'Koramangala 5th Block, Bengaluru, Karnataka',
        region: 'Bengaluru',
        price: 2400,
        rating: 3.8,
        badge: 'SIMPLE CITY ROOM',
        image: 'https://media.easemytrip.com/media/Hotel/SHL-23031000708042/Common/CommontfeC8o.jpg',
        description: 'A budget-friendly hotel option in Koramangala for short city visits and practical stays.',
        features: ['Private room', 'Wi-Fi', 'Nearby cafés', 'Easy city access'],
        amenities: [],
        mood: ['Lively'],
        purpose: ['Business', 'Leisure'],
        roomTypes: ['Basic', 'Standard'],
        areas: ['bengaluru', 'bangalore', 'koramangala', 'hsr layout', 'karnataka']
    },
    {
        id: 'whitefield-budget',
        name: 'Bloom Hotel - Brookefield',
        area: 'Brookefield, Bengaluru, Karnataka',
        region: 'Bengaluru',
        price: 2200,
        rating: 3.7,
        badge: 'WORK-TRIP BASIC',
        image: 'https://img.lentlo.com/images/listing-img-98386/w-640.webp',
        description: 'A contemporary hotel in Brookefield with bright rooms and simple modern comforts.',
        features: ['Air conditioning', 'Wi-Fi', 'Work-trip location', 'Restaurant'],
        amenities: [],
        mood: ['Lively'],
        purpose: ['Business'],
        roomTypes: ['Basic', 'Standard'],
        areas: ['bengaluru', 'bangalore', 'brookefield', 'whitefield', 'marathahalli', 'karnataka']
    },
    {
        id: 'jayanagar-stay',
        name: 'Octave Hotel & Spa - JP Nagar',
        area: 'JP Nagar, Bengaluru, Karnataka',
        region: 'Bengaluru',
        price: 2600,
        rating: 3.9,
        badge: 'NEIGHBOURHOOD STAY',
        image: 'https://cf.bstatic.com/xdata/images/hotel/max1024x768/73602281.jpg?k=d07f67cc70f1ccdc23b55d16059d3e69992ebdbfee7503fc9eafc30a9c087608&o=',
        description: 'A straightforward hotel with private rooms in south Bengaluru, suited to short leisure or work stays.',
        features: ['Private room', 'Wi-Fi', 'Local eateries', 'Neighbourhood location'],
        amenities: [],
        mood: ['Quiet'],
        purpose: ['Leisure', 'Family'],
        roomTypes: ['Basic', 'Standard'],
        areas: ['bengaluru', 'bangalore', 'jp nagar', 'jayanagar', 'karnataka']
    },
    {
        id: 'electronic-city-basic',
        name: 'Lemon Tree Hotel, Electronics City',
        area: 'Electronic City Phase 1, Bengaluru, Karnataka',
        region: 'Bengaluru',
        price: 1900,
        rating: 3.7,
        badge: 'BASIC WORK-TRIP ROOM',
        image: 'https://www.lemontreehotels.com/uploads/hotelgallery/04_Jul_2023_06_09_59Superior-King-Room-%283%29.jpg',
        description: 'A full-service hotel in Electronics City with contemporary rooms for business and leisure stays.',
        features: ['Air conditioning', 'Wi-Fi', 'Work-trip location', 'Restaurant'],
        amenities: [],
        mood: ['Lively'],
        purpose: ['Business'],
        roomTypes: ['Basic', 'Standard'],
        areas: ['bengaluru', 'bangalore', 'electronic city', 'bommasandra', 'karnataka']
    }
];

const destinations = [
    ['India', 'Explore sample stays across India', 'Country', ['all-india']],
    ['Goa', 'Coastal escapes · Goa', 'Popular destination', ['goa']],
    ['Bengaluru', 'City breaks · Karnataka', 'City', ['bengaluru', 'bangalore']],
    ['Bangalore', 'Also known as Bengaluru · Karnataka', 'City', ['bengaluru', 'bangalore']],
    ['Mumbai', 'Waterfront and city stays · Maharashtra', 'City', ['mumbai', 'bombay']],
    ['Delhi', 'Heritage and city stays · Delhi NCR', 'City', ['delhi', 'new delhi', 'ncr']],
    ['New Delhi', 'Capital city stays · Delhi', 'City', ['delhi', 'new delhi', 'ncr']],
    ['Jaipur', 'Palaces and heritage · Rajasthan', 'City', ['jaipur']],
    ['Udaipur', 'Lakeside escapes · Rajasthan', 'City', ['udaipur']],
    ['Kochi', 'Backwaters · Kerala', 'City', ['kochi', 'cochin']],
    ['Chennai', 'Coastal city stays · Tamil Nadu', 'City', ['chennai']],
    ['Hyderabad', 'Heritage and modern city stays · Telangana', 'City', ['hyderabad']],
    ['Agra', 'Taj Mahal and heritage stays · Uttar Pradesh', 'City', ['agra']],
    ['Shimla', 'Mountain retreats · Himachal Pradesh', 'Mountain destination', ['shimla']],
    ['Manali', 'Mountain and riverside stays · Himachal Pradesh', 'Mountain destination', ['manali']],
    ['Kolkata', 'Culture and city stays · West Bengal', 'City', ['kolkata']],
    ['Varanasi', 'Heritage and cultural stays · Uttar Pradesh', 'City', ['varanasi']],
    ['Kerala', 'Backwaters and coastal escapes', 'State', ['kerala', 'kochi', 'cochin']],
    ['Rajasthan', 'Palaces, forts and desert cities', 'State', ['rajasthan', 'jaipur', 'udaipur']],
    ['Himachal Pradesh', 'Mountain escapes in North India', 'State', ['himachal pradesh', 'shimla', 'manali']],
    ['Baga', 'Beach and nightlife · North Goa', 'Beach area', ['baga']],
    ['Calangute', 'Beachfront stays · North Goa', 'Beach area', ['calangute']],
    ['Candolim', 'Resorts and quieter beach days · North Goa', 'Beach area', ['candolim', 'sinquerim']],
    ['Panaji', 'Riverfront city breaks · Goa', 'City', ['panaji', 'miramar']],
    ['Anjuna', 'Beach cafés and bohemian energy · North Goa', 'Beach area', ['anjuna', 'vagator', 'morjim']],
    ['Vagator', 'Clifftop sunsets · North Goa', 'Beach area', ['vagator', 'anjuna', 'morjim']],
    ['Majorda', 'Peaceful beaches · South Goa', 'Beach area', ['majorda']],
    ['South Goa', 'Slow stays and quieter shores', 'Region', ['south goa', 'majorda', 'benaulim', 'varca', 'mobor']],
    ['Benaulim', 'Relaxed beach escape · South Goa', 'Beach area', ['benaulim']],
    ['Mobor', 'Resort stays · South Goa', 'Beach area', ['mobor']],
    ['Indiranagar', 'Cafés and city stays · Bengaluru, Karnataka', 'Bengaluru neighbourhood', ['indiranagar', 'domlur']],
    ['Koramangala', 'Student-friendly cafés and stays · Bengaluru, Karnataka', 'Bengaluru neighbourhood', ['koramangala']],
    ['Whitefield', 'IT corridor and business stays · Bengaluru, Karnataka', 'Bengaluru neighbourhood', ['whitefield', 'itpl']],
    ['MG Road', 'Central Bengaluru shopping and business area · Karnataka', 'Bengaluru neighbourhood', ['mg road', 'brigade road', 'commercial street']],
    ['Majestic', 'Transit hub and budget rooms · Bengaluru, Karnataka', 'Bengaluru neighbourhood', ['majestic', 'gandhinagar', 'yeshwanthpur']],
    ['Electronic City', 'IT parks and work-trip stays · Bengaluru, Karnataka', 'Bengaluru neighbourhood', ['electronic city', 'bommasandra']],
    ['Jayanagar', 'Residential neighbourhood stays · Bengaluru, Karnataka', 'Bengaluru neighbourhood', ['jayanagar', 'jp nagar']],
    ['HSR Layout', 'Cafés and residential stays · Bengaluru, Karnataka', 'Bengaluru neighbourhood', ['hsr layout']],
    ['Marathahalli', 'Budget and business stays · Bengaluru, Karnataka', 'Bengaluru neighbourhood', ['marathahalli']]
].map(([name, detail, type, terms]) => ({ name, detail, type, terms }));

const state = {
    destination: 'India',
    adults: 2,
    children: 0,
    rooms: 1,
    childAges: [],
    checkin: '',
    checkout: '',
    activeHotels: [...hotels],
    sort: 'recommended',
    user: null,
    saved: new Set()
};

const store = {
    get(key, fallback) { try { return JSON.parse(localStorage.getItem('veyora_' + key)) ?? fallback; } catch { return fallback; } },
    set(key, value) { try { localStorage.setItem('veyora_' + key, JSON.stringify(value)); } catch {} }
};
state.user = store.get('user', null);
state.saved = new Set(store.get('saved', []));
state.trips = store.get('trips', []);
state.stayPrefs = store.get('stayPrefs', { bed: 'King', floor: 'No preference', extras: [] });

const $ = id => document.getElementById(id);
const destinationInput = $('destinationInput');
const suggestions = $('destinationSuggestions');
const guestPopover = $('guestPopover');
const guestTrigger = $('guestTrigger');
const modalBackdrop = $('modalBackdrop');
const modalBody = $('modalBody');

const esc = value => String(value).replace(/[&<>"']/g, character => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
}[character]));

function iso(date) {
    return new Date(date.getTime() - date.getTimezoneOffset() * 60000)
        .toISOString()
        .slice(0, 10);
}

function setDefaultDates() {
    const today = new Date();
    const tomorrow = new Date(today);

    tomorrow.setDate(today.getDate() + 1);

    $('checkinInput').min = iso(today);
    $('checkinInput').value = iso(today);

    $('checkoutInput').min = iso(tomorrow);
    $('checkoutInput').value = iso(tomorrow);

    state.checkin = $('checkinInput').value;
    state.checkout = $('checkoutInput').value;
}

function nights() {
    return Math.max(
        1,
        Math.round(
            (
                new Date(state.checkout + 'T12:00:00') -
                new Date(state.checkin + 'T12:00:00')
            ) / 86400000
        ) || 1
    );
}

function dateLabel(value) {
    return value
        ? new Date(value + 'T12:00:00').toLocaleDateString('en-IN', {
            day: 'numeric',
            month: 'short'
        })
        : 'Select date';
}

function guestText() {
    return `${state.adults} adult${state.adults === 1 ? '' : 's'} · ` +
        `${state.children} child${state.children === 1 ? '' : 'ren'} · ` +
        `${state.rooms} room${state.rooms === 1 ? '' : 's'}`;
}

function updateGuestSummary() {
    $('guestSummary').textContent = guestText();
    $('adultsCount').textContent = state.adults;
    $('childrenCount').textContent = state.children;
    $('roomsCount').textContent = state.rooms;

    renderChildAges();
    updateSearchSummary();
}

function renderChildAges() {
    const holder = $('childAges');
    holder.innerHTML = '';

    for (let i = 0; i < state.children; i++) {
        const row = document.createElement('div');
        row.className = 'child-age-row';

        const label = document.createElement('label');
        label.textContent = `Child ${i + 1} age`;
        label.htmlFor = `childAge${i}`;

        const select = document.createElement('select');
        select.id = `childAge${i}`;

        for (let age = 0; age <= 17; age++) {
            const option = document.createElement('option');
            option.value = age;
            option.textContent = age === 0 ? 'Under 1 year' : `${age} years`;
            option.selected = (state.childAges[i] ?? 7) === age;
            select.appendChild(option);
        }

        select.addEventListener('change', () => {
            state.childAges[i] = Number(select.value);
        });

        row.append(label, select);
        holder.appendChild(row);
    }
}

function updateSearchSummary() {
    $('searchSummaryText').textContent =
        `Showing stays in ${state.destination || 'India'}`;

    $('occupancySummary').textContent =
        `${state.adults} adult${state.adults === 1 ? '' : 's'}` +
        `${state.children
            ? `, ${state.children} child${state.children === 1 ? '' : 'ren'} ` +
              `(${state.childAges.map(age => age === 0 ? 'under 1' : `${age} yrs`).join(', ')})`
            : ''}` +
        ` · ${state.rooms} room${state.rooms === 1 ? '' : 's'}` +
        ` · ${nights()} night${nights() === 1 ? '' : 's'}`;

    updateTripBudget();
}

function renderSuggestions(query = '') {
    const q = query.trim().toLowerCase();

    const matches = destinations
        .filter(destination =>
            !q ||
            destination.name.toLowerCase().includes(q) ||
            destination.detail.toLowerCase().includes(q)
        )
        .sort((a, b) =>
            (a.name.toLowerCase().startsWith(q) ? 0 : 1) -
            (b.name.toLowerCase().startsWith(q) ? 0 : 1)
        )
        .slice(0, 8);

    suggestions.innerHTML =
        '<div class="suggestion-title">' +
        (q ? 'DESTINATIONS & NEIGHBOURHOODS' : 'POPULAR ACROSS INDIA') +
        '</div>';

    matches.forEach(destination => {
        const button = document.createElement('button');

        button.className = 'suggestion-option';
        button.type = 'button';
        button.setAttribute('role', 'option');

        button.innerHTML =
            `<span class="suggestion-pin">⌖</span>` +
            `<span><strong>${esc(destination.name)}</strong>` +
            `<small>${esc(destination.detail)}</small></span>`;

        button.addEventListener('click', () => {
            chooseDestination(destination.name);
        });

        suggestions.appendChild(button);
    });

    if (!matches.length) {
        suggestions.insertAdjacentHTML(
            'beforeend',
            '<div class="suggestion-title">' +
            'No matching suggestion. Press Enter to search this place.' +
            '</div>'
        );
    }

    suggestions.classList.add('open');
}

function destinationTerms(value) {
    const query = value.trim().toLowerCase();

    const destination =
        destinations.find(item => item.name.toLowerCase() === query) ||
        destinations.find(item => item.name.toLowerCase().startsWith(query));

    return destination ? destination.terms : [query];
}

function hotelsForDestination(value) {
    const query = value.trim().toLowerCase();
    const terms = destinationTerms(value).map(term => term.toLowerCase());

    if (!query || query === 'india' || terms.includes('all-india')) {
        return [...hotels];
    }

    return hotels.filter(hotel =>
        hotel.areas.some(area => terms.includes(area.toLowerCase())) ||
        hotel.region.toLowerCase() === query
    );
}

function chooseDestination(name) {
    state.destination = name;
    destinationInput.value = name;
    suggestions.classList.remove('open');

    document.querySelectorAll('.destination-chip').forEach(chip => {
        chip.classList.toggle(
            'selected',
            chip.dataset.destination.toLowerCase() === name.toLowerCase()
        );
    });

    runSearch(false);
}

function sortHotels(list) {
    const result = [...list];

    if (state.sort === 'price-low') {
        result.sort((a, b) => a.price - b.price);
    } else if (state.sort === 'price-high') {
        result.sort((a, b) => b.price - a.price);
    } else if (state.sort === 'rating') {
        result.sort((a, b) => b.rating - a.rating);
    }

    return result;
}

function renderHotels(list) {
    const grid = $('hotelGrid');
    grid.innerHTML = '';

    $('resultsCount').textContent =
        `${list.length} ${list.length === 1 ? 'stay' : 'stays'} to explore`;

    $('emptyState').classList.toggle('hidden', list.length > 0);

    list.forEach(hotel => {
        const card = document.createElement('article');
        card.className = 'hotel-card';

        card.innerHTML = `
            <div class="hotel-photo-wrap">
                <img
                    class="hotel-photo"
                    src="${hotel.image}"
                    onerror="this.onerror=null;this.src='${hotel.fallbackImage}'"
                    alt="Room photograph for ${esc(hotel.name)}"
                    loading="lazy"
                >
                <span class="hotel-badge">${esc(hotel.badge)}</span>
                ${hotel.matchScore ? `<span class="match-pill">${hotel.matchScore}% match</span>` : ''}
                <button
                    class="save-hotel ${state.saved.has(hotel.id) ? 'saved' : ''}"
                    type="button"
                    aria-label="Save to favourites"
                >${state.saved.has(hotel.id) ? '♥' : '♡'}</button>
            </div>

            <div class="hotel-content">
                <div class="hotel-location">⌖ ${esc(hotel.area)}</div>

                <div class="hotel-title-row">
                    <h3>${esc(hotel.name)}</h3>
                    <div class="hotel-rating">
                        ${hotel.rating.toFixed(1)}
                        <span>Guest rating*</span>
                    </div>
                </div>

                <p class="hotel-description">${esc(hotel.description)}</p>
                ${hotel.reasons ? `<p class="match-why">✓ ${esc(hotel.reasons.join(' · '))}</p>` : ''}

                <div class="hotel-features">
                    ${hotel.features.slice(0, 4).map(feature =>
                        `<span class="hotel-feature">${esc(feature)}</span>`
                    ).join('')}
                </div>

                <div class="hotel-bottom">
                    <div>
                        <div class="price-label">SAMPLE RATE / NIGHT</div>
                        <div class="hotel-price">
                            ₹${hotel.price.toLocaleString('en-IN')}
                            <small> / night</small>
                        </div>
                        <div class="hotel-total-note">
                            Illustrative · taxes not calculated
                        </div>
                    </div>

                    <div class="hotel-actions">
                        <button class="outline-button details-action" type="button">
                            Details
                        </button>
                        <button class="details-button book-action" type="button">
                            Choose ↗
                        </button>
                    </div>
                </div>
            </div>
        `;

        card.querySelector('.save-hotel').addEventListener('click', () => {
            if (state.saved.has(hotel.id)) {
                state.saved.delete(hotel.id);
            } else {
                state.saved.add(hotel.id);
            }
            store.set('saved', [...state.saved]);

            renderHotels(state.activeHotels);

            toast(
                state.saved.has(hotel.id)
                    ? 'Saved to your favourites.'
                    : 'Removed from your favourites.'
            );
        });

        card.querySelector('.details-action').addEventListener('click', () => {
            showHotelDetails(hotel);
        });

        card.querySelector('.book-action').addEventListener('click', () => {
            showBooking(hotel);
        });

        grid.appendChild(card);
    });
}

function runSearch(scroll = true) {
    state.destination = destinationInput.value.trim() || 'India';
    state.checkin = $('checkinInput').value;
    state.checkout = $('checkoutInput').value;

    if (!state.checkin || !state.checkout || state.checkout <= state.checkin) {
        toast('Choose a check-out date after your check-in date.');
        return;
    }

    const matches = hotelsForDestination(state.destination);

    state.activeHotels = sortHotels(matches);

    renderHotels(state.activeHotels);
    updateSearchSummary();

    suggestions.classList.remove('open');
    guestPopover.classList.remove('open');

    document.querySelectorAll('.destination-chip').forEach(chip => {
        chip.classList.toggle(
            'selected',
            chip.dataset.destination.toLowerCase() === state.destination.toLowerCase()
        );
    });

    if (scroll) {
        $('stays').scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });

        toast(
            matches.length
                ? `Found ${matches.length} sample stays in ${state.destination}.`
                : `No sample listings for ${state.destination} yet. Try another city or choose All India.`
        );
    }
}

function showHotelDetails(hotel) {
    openModal(`
        <div class="modal-kicker">A CLOSER LOOK</div>
        <h2 id="modalTitle">${esc(hotel.name)}</h2>

        <p class="modal-lead">
            ⌖ ${esc(hotel.area)} · Property/sample listing · illustrative demo
        </p>

        <img
            class="modal-hotel-image"
            src="${hotel.image}"
            onerror="this.onerror=null;this.src='${hotel.fallbackImage}'"
            alt="Room photograph for ${esc(hotel.name)}"
        >

        <p class="modal-lead">${esc(hotel.description)}</p>

        <div class="modal-facts">
            ${hotel.features.map(feature => `<span>${esc(feature)}</span>`).join('')}
            <span>Guest rating ${hotel.rating.toFixed(1)}/5 (illustrative)</span>
            <span>Room types: ${hotel.roomTypes.join(', ')}</span>
        </div>

        <div class="modal-price-row">
            <div>
                <strong>₹${hotel.price.toLocaleString('en-IN')}</strong>
                <small>Sample rate per night · not a live quote</small>
            </div>
            <span>${nights()} night${nights() === 1 ? '' : 's'}</span>
        </div>

        <div class="demo-alert">
            Photos are representative imagery and may not show this exact hotel.
            Prices and availability are demo data. No live inventory is connected.
        </div>

        <button class="button button-dark" id="modalChooseHotel">
            Continue with this stay <span>↗</span>
        </button>
    `);

    $('modalChooseHotel').addEventListener('click', () => {
        showBooking(hotel);
    });
}

const EXTRAS = [
    { id: 'pickup', label: 'Airport pickup', price: 1500, once: true },
    { id: 'latecheckout', label: 'Late checkout', price: 1200, once: true },
    { id: 'celebration', label: 'Celebration setup (flowers, cake)', price: 2000, once: true },
    { id: 'extrabed', label: 'Extra bed', price: 1500, once: false },
    { id: 'quiet', label: 'Quiet room, away from lifts', price: 0, once: true }
];

const inr = value => '₹' + Number(value).toLocaleString('en-IN');

function showBooking(hotel) {
    const base = hotel.price * nights() * state.rooms;
    const prefs = state.stayPrefs;
    const user = state.user || {};
    const pick = (id, options, current) => `<select id="${id}">${options.map(o =>
        `<option ${o === current ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select>`;
    const extrasTotal = () => EXTRAS.filter(e => $('ex_' + e.id).checked)
        .reduce((sum, e) => sum + e.price * (e.once ? 1 : nights()), 0);

    openModal(`
        <div class="modal-kicker">YOUR STAY, YOUR WAY</div>
        <h2 id="modalTitle">Make it yours</h2>
        <p class="modal-lead">${esc(hotel.name)} · ${esc(hotel.area)}</p>

        <div class="modal-facts">
            <span>${dateLabel(state.checkin)} – ${dateLabel(state.checkout)}</span>
            <span>${guestText()}</span>
            <span>${nights()} night${nights() === 1 ? '' : 's'}</span>
        </div>

        <div class="custom-grid">
            <label class="form-field"><span>Guest name</span><input id="gName" value="${esc(user.name || '')}" placeholder="Full name"></label>
            <label class="form-field"><span>Phone</span><input id="gPhone" type="tel" placeholder="+91 98765 43210"></label>
            <label class="form-field"><span>Room type</span>${pick('gRoom', hotel.roomTypes, hotel.roomTypes[0])}</label>
            <label class="form-field"><span>Bed setup</span>${pick('gBed', ['King', 'Twin', 'Double'], prefs.bed)}</label>
            <label class="form-field"><span>Floor</span>${pick('gFloor', ['No preference', 'High floor', 'Low floor'], prefs.floor)}</label>
        </div>

        <div class="opt-list">
            ${EXTRAS.map(e => `
                <label class="opt-row">
                    <input type="checkbox" id="ex_${e.id}" ${prefs.extras.includes(e.id) ? 'checked' : ''}>
                    ${esc(e.label)}
                    <em>${e.price ? '+' + inr(e.price) + (e.once ? '' : ' / night') : 'free'}</em>
                </label>`).join('')}
        </div>

        <label class="form-field"><span>Anything else we should know?</span><textarea id="gNote" placeholder="Allergies, a surprise, an early arrival..."></textarea></label>
        <label class="opt-row"><input type="checkbox" id="gRemember" checked> Remember these choices for my next stay</label>

        <div class="modal-price-row">
            <div><strong id="bookTotal">${inr(base)}</strong><small>Illustrative total with your choices · demo only</small></div>
        </div>
        <div class="demo-alert">No real booking or payment will take place. Your stay is saved on this device only.</div>
        <button class="button button-accent" id="confirmDemoBtn">Confirm my stay <span>✓</span></button>
    `);

    const refresh = () => { $('bookTotal').textContent = inr(base + extrasTotal()); };
    modalBody.querySelectorAll('.opt-row input').forEach(box => box.addEventListener('change', refresh));
    refresh();

    $('confirmDemoBtn').addEventListener('click', () => {
        const name = $('gName').value.trim();
        if (!name) { toast('Add the guest name to continue.'); $('gName').focus(); return; }

        const chosen = EXTRAS.filter(e => $('ex_' + e.id).checked);
        const booking = {
            name,
            phone: $('gPhone').value.trim(),
            room: $('gRoom').value,
            bed: $('gBed').value,
            floor: $('gFloor').value,
            note: $('gNote').value.trim(),
            extras: chosen.map(e => e.label),
            total: base + extrasTotal()
        };

        if ($('gRemember').checked) {
            state.stayPrefs = { bed: booking.bed, floor: booking.floor, extras: chosen.map(e => e.id) };
            store.set('stayPrefs', state.stayPrefs);
        }

        confirmDemo(hotel, booking);
    });
}

function confirmDemo(hotel, booking) {
    const reference = 'VY-' + Math.random().toString(36).slice(2, 8).toUpperCase();

    state.trips.unshift({
        ref: reference,
        hotelName: hotel.name,
        area: hotel.area,
        checkin: state.checkin,
        checkout: state.checkout,
        guests: guestText(),
        status: 'Confirmed',
        ...booking
    });
    store.set('trips', state.trips);

    openModal(`
        <div class="success-mark">✓</div>
        <div class="modal-kicker">STAY CONFIRMED (DEMO)</div>
        <h2 id="modalTitle">That’s a lovely plan, ${esc(booking.name.split(' ')[0])}.</h2>
        <p class="modal-lead">Your stay at <strong>${esc(hotel.name)}</strong> is saved to My trips. No real reservation was made.</p>
        <div class="booking-reference">${reference}</div>
        <div class="modal-facts">
            <span>${dateLabel(state.checkin)} – ${dateLabel(state.checkout)}</span>
            <span>${esc(booking.room)} · ${esc(booking.bed)} bed</span>
            <span>${esc(booking.floor)}</span>
            ${booking.extras.map(x => `<span>${esc(x)}</span>`).join('')}
        </div>
        <div class="modal-price-row">
            <div><strong>${inr(booking.total)}</strong><small>Illustrative total · no payment collected</small></div>
        </div>
        <button class="button button-dark" id="viewTripsBtn">View my trips <span>↗</span></button>
        <button class="modal-link" id="doneBtn">Back to exploring</button>
    `);

    $('viewTripsBtn').addEventListener('click', openTrips);
    $('doneBtn').addEventListener('click', closeModal);
}

function openTrips() {
    const list = state.trips.map(t => `
        <div class="trip-card">
            <div class="trip-head">
                <div><h3>${esc(t.hotelName)}</h3><small>⌖ ${esc(t.area)}</small></div>
                <span class="trip-ref">${esc(t.ref)}</span>
            </div>
            <small>${dateLabel(t.checkin)} – ${dateLabel(t.checkout)} · ${esc(t.guests)}</small>
            <small>${esc(t.room)} · ${esc(t.bed)} bed · ${esc(t.floor)}</small>
            ${t.extras.length ? `<small>Extras: ${t.extras.map(x => esc(x)).join(', ')}</small>` : ''}
            ${t.note ? `<small>Your note: ${esc(t.note)}</small>` : ''}
            <div class="modal-price-row">
                <div><strong>${inr(t.total)}</strong><small>Illustrative total</small></div>
                <span>${esc(t.status)}</span>
            </div>
            <div class="trip-actions"><button class="outline-button" data-cancel="${esc(t.ref)}">Cancel stay</button></div>
        </div>`).join('');

    openModal(`
        <div class="modal-kicker">MY TRIPS</div>
        <h2 id="modalTitle">Your stays</h2>
        ${list || '<p class="modal-lead">No stays yet. Pick a hotel and make it yours.</p>'}
    `);

    modalBody.querySelectorAll('[data-cancel]').forEach(button => button.addEventListener('click', () => {
        state.trips = state.trips.filter(t => t.ref !== button.dataset.cancel);
        store.set('trips', state.trips);
        openTrips();
        toast('Stay cancelled.');
    }));
}

function openModal(html) {
    modalBody.innerHTML = html;
    modalBackdrop.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    modalBackdrop.classList.add('hidden');
    document.body.style.overflow = '';
}

function toast(message) {
    const toastElement = $('toast');

    toastElement.textContent = message;
    toastElement.classList.add('show');

    clearTimeout(toast.timer);

    toast.timer = setTimeout(() => {
        toastElement.classList.remove('show');
    }, 2700);
}

function runSmartMatch() {
    const budget = Math.max(
        1000,
        Number($('budgetInput').value) || 8000
    );

    const purpose = $('purposeSelect').value;
    const mood = $('atmosphereSelect').value;
    const amenity = $('amenitySelect').value;
    const roomType = $('roomTypeSelect')?.value || 'Any';

    store.set('smartPrefs', { budget, purpose, mood, amenity, roomType });

    const pool = hotelsForDestination(state.destination);

    const scored = pool.map(hotel => {
        let score = hotel.price <= budget
            ? 30
            : Math.max(0, 30 - ((hotel.price - budget) / budget) * 30);

        if (purpose === 'Any' || hotel.purpose.includes(purpose)) {
            score += 15;
        }

        if (mood === 'Any' || hotel.mood.includes(mood)) {
            score += 15;
        }

        if (amenity === 'Any' || hotel.amenities.includes(amenity)) {
            score += 25;
        }

        if (roomType === 'Any' || hotel.roomTypes.includes(roomType)) {
            score += 15;
        }

        score += hotel.rating / 5 * 15;

        const reasons = [];
        if (hotel.price <= budget) reasons.push('within budget');
        if (purpose !== 'Any' && hotel.purpose.includes(purpose)) reasons.push(purpose.toLowerCase() + ' friendly');
        if (mood !== 'Any' && hotel.mood.includes(mood)) reasons.push(mood.toLowerCase() + ' feel');
        if (amenity !== 'Any' && hotel.amenities.includes(amenity)) reasons.push('has ' + amenity);
        if (roomType !== 'Any' && hotel.roomTypes.includes(roomType)) reasons.push(roomType.toLowerCase() + ' room available');
        if (!reasons.length) reasons.push('top rated');

        return {
            ...hotel,
            reasons,
            matchScore: Math.min(99, Math.round(score / 115 * 100))
        };
    }).sort((a, b) => b.matchScore - a.matchScore);

    let matches = scored.filter(hotel =>
        hotel.price <= budget &&
        (roomType === 'Any' || hotel.roomTypes.includes(roomType)) &&
        (amenity === 'Any' || hotel.amenities.includes(amenity)) &&
        (purpose === 'Any' || hotel.purpose.includes(purpose)) &&
        (mood === 'Any' || hotel.mood.includes(mood))
    );

    if (!matches.length) {
        matches = scored.filter(hotel => hotel.price <= budget);
    }

    state.activeHotels = sortHotels(
        matches.length ? matches : scored.slice(0, 6)
    );

    renderHotels(state.activeHotels);

    $('resultsCount').textContent =
        `${state.activeHotels.length} ` +
        `${matches.length ? 'stays matched' : 'closest stays to explore'}`;

    $('stays').scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });

    toast(
        matches.length
            ? 'Showing stays that fit your selected budget and preferences.'
            : 'No exact matches within that budget, so we are showing the closest sample stays.'
    );
}

function openAuth(mode = 'register') {
    const isRegister = mode === 'register';

    openModal(`
        <div class="modal-kicker">WELCOME TO VEYORA</div>

        <h2 id="modalTitle">
            ${isRegister ? 'Make yourself at home.' : 'Welcome back.'}
        </h2>

        <p class="modal-lead">
            This is a frontend demo profile, not a real account.
        </p>

        <form id="authForm">
            ${isRegister
                ? `<label class="form-field">
                    <span>Full name</span>
                    <input id="authName" required placeholder="Your name">
                </label>`
                : ''
            }

            <label class="form-field">
                <span>Email address</span>
                <input id="authEmail" type="email" required placeholder="you@example.com">
            </label>

            <label class="form-field">
                <span>Password</span>
                <input
                    id="authPassword"
                    type="password"
                    minlength="6"
                    required
                    placeholder="At least 6 characters"
                >
            </label>

            <button class="button button-dark" type="submit">
                ${isRegister ? 'Create demo account' : 'Sign in to demo'} ↗
            </button>
        </form>

        <p class="form-note">
            Not connected to the Java/MySQL backend yet. Passwords are not saved.
        </p>

        <button class="modal-link" id="switchAuthBtn">
            ${isRegister
                ? 'Already have a demo profile? Sign in'
                : 'New to VEYORA? Create a demo profile'}
        </button>
    `);

    $('authForm').addEventListener('submit', event => {
        event.preventDefault();

        const email = $('authEmail').value.trim();

        const name = isRegister
            ? $('authName').value.trim()
            : email.split('@')[0];

        state.user = { name, email };
        store.set('user', state.user);

        updateUserUI();

        openModal(`
            <div class="success-mark">✓</div>
            <div class="modal-kicker">DEMO PROFILE</div>

            <h2 id="modalTitle">
                Welcome, ${esc(name.split(/[ ._-]/)[0])}.
            </h2>

            <p class="modal-lead">
                You are using the local VEYORA demo as ${esc(email)}.
                No server account was created.
            </p>

            <button class="button button-dark" id="authDoneBtn">
                Explore stays ↗
            </button>
        `);

        $('authDoneBtn').addEventListener('click', closeModal);
    });

    $('switchAuthBtn').addEventListener('click', () => {
        openAuth(isRegister ? 'signin' : 'register');
    });
}

function updateUserUI() {
    const signInButton = $('signInBtn');
    const getStartedButton = $('getStartedBtn');

    if (state.user) {
        signInButton.textContent = `Hi, ${state.user.name.split(' ')[0]}`;

        getStartedButton.textContent = 'Sign out';
    } else {
        signInButton.textContent = 'Sign in';

        getStartedButton.textContent = 'Get started ↗';
    }
}

function openAccountMenu() {
    openModal(`
        <div class="modal-kicker">YOUR VEYORA PROFILE</div>

        <h2 id="modalTitle">
            Hey, ${esc(state.user?.name || 'traveller')}.
        </h2>

        <p class="modal-lead">${esc(state.user?.email || '')}</p>

        <div class="demo-alert">This is a local demo profile.</div>

        <button class="button button-dark" id="accountCloseBtn">
            Keep exploring ↗
        </button>

        <button class="modal-link" id="accountSignOutBtn">
            Sign out
        </button>
    `);

    $('accountCloseBtn').addEventListener('click', closeModal);

    $('accountSignOutBtn').addEventListener('click', () => {
        closeModal();
        signOut();
    });
}

function signOut() {
    state.user = null;
    store.set('user', null);
    updateUserUI();
    toast('You’ve signed out of the demo.');
}

// --------------------------------------------------
// INITIAL SETUP
// --------------------------------------------------

// Property-specific room photos are linked from hotel/operator or hotel-gallery pages.
// Keep a generic fallback only if an external image host blocks hotlinking.
hotels.forEach(hotel => {
    hotel.fallbackImage = photo.room;
});

setDefaultDates();
updateGuestSummary();
updateUserUI();
renderHotels(sortHotels(hotelsForDestination(state.destination)));
updateSearchSummary();

// Destination autocomplete
destinationInput.addEventListener('focus', () => {
    renderSuggestions(destinationInput.value);
});

destinationInput.addEventListener('input', () => {
    renderSuggestions(destinationInput.value);
});

destinationInput.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
        suggestions.classList.remove('open');
    }

    if (event.key === 'Enter') {
        event.preventDefault();

        const query = destinationInput.value.trim().toLowerCase();

        const destination =
            destinations.find(item => item.name.toLowerCase() === query) ||
            destinations.find(item => item.name.toLowerCase().startsWith(query));

        if (destination) {
            chooseDestination(destination.name);
        } else {
            runSearch();
        }
    }
});

// Close popovers when clicking outside
document.addEventListener('click', event => {
    if (!event.target.closest('.destination-field')) {
        suggestions.classList.remove('open');
    }

    if (!event.target.closest('.guest-field')) {
        guestPopover.classList.remove('open');
    }
});

// Guest selector
guestTrigger.addEventListener('click', event => {
    event.stopPropagation();

    guestPopover.classList.toggle('open');
    suggestions.classList.remove('open');
});

$('closeGuestPopover').addEventListener('click', () => {
    guestPopover.classList.remove('open');
});

$('applyGuestsBtn').addEventListener('click', () => {
    guestPopover.classList.remove('open');
    updateGuestSummary();
});

// Adults, children and room counters
document.querySelectorAll('[data-counter]').forEach(button => {
    button.addEventListener('click', () => {
        const key = button.dataset.counter;
        const step = Number(button.dataset.step);

        if (key === 'adults') {
            state.adults = Math.min(12, Math.max(1, state.adults + step));
        }

        if (key === 'children') {
            const next = Math.min(6, Math.max(0, state.children + step));

            if (next < state.children) {
                state.childAges.length = next;
            } else {
                while (state.childAges.length < next) {
                    state.childAges.push(7);
                }
            }

            state.children = next;
        }

        if (key === 'rooms') {
            state.rooms = Math.min(8, Math.max(1, state.rooms + step));
        }

        updateGuestSummary();
    });
});

// Check-in date
$('checkinInput').addEventListener('change', () => {
    const value = $('checkinInput').value;
    const nextDate = new Date(value + 'T12:00:00');

    nextDate.setDate(nextDate.getDate() + 1);

    $('checkoutInput').min = iso(nextDate);

    if ($('checkoutInput').value <= value) {
        $('checkoutInput').value = iso(nextDate);
    }

    state.checkin = $('checkinInput').value;
    state.checkout = $('checkoutInput').value;

    updateSearchSummary();
});

// Check-out date
$('checkoutInput').addEventListener('change', () => {
    state.checkout = $('checkoutInput').value;
    updateSearchSummary();
});

// Search controls
$('searchBtn').addEventListener('click', () => {
    runSearch();
});

$('editSearchBtn').addEventListener('click', () => {
    $('searchPanel').scrollIntoView({
        behavior: 'smooth',
        block: 'center'
    });

    destinationInput.focus();
});

// Sort hotel results
$('sortSelect').addEventListener('change', () => {
    state.sort = $('sortSelect').value;
    state.activeHotels = sortHotels(state.activeHotels);
    renderHotels(state.activeHotels);
});

// Reset search
$('resetSearchBtn').addEventListener('click', () => {
    destinationInput.value = 'India';
    state.destination = 'India';
    runSearch(false);
});

// Popular destination chips
document.querySelectorAll('.destination-chip').forEach(chip => {
    chip.addEventListener('click', () => {
        destinationInput.value = chip.dataset.destination;

        chooseDestination(chip.dataset.destination);

        $('stays').scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    });
});

// --------------------------------------------------
// SMARTMATCH BUDGET SLIDER AND TRIP ESTIMATE
// --------------------------------------------------

const budgetSlider = $('budgetInput');
const budgetValue = $('budgetValue');

function money(value) {
    return '₹' + Number(value).toLocaleString('en-IN');
}

function updateTripBudget() {
    const nightly = Number($('budgetInput')?.value || 8000);
    const total = nightly * state.rooms * nights();

    if ($('tripBudgetNightly')) {
        $('tripBudgetNightly').textContent = money(nightly);
    }

    if ($('tripBudgetMultiplier')) {
        $('tripBudgetMultiplier').textContent =
            `${state.rooms} room${state.rooms === 1 ? '' : 's'} × ` +
            `${nights()} night${nights() === 1 ? '' : 's'}`;
    }

    if ($('tripBudgetTotal')) {
        $('tripBudgetTotal').textContent = money(total);
    }

    if ($('tripBudgetDetails')) {
        $('tripBudgetDetails').textContent =
            `${money(nightly)} × ${state.rooms} room${state.rooms === 1 ? '' : 's'} × ` +
            `${nights()} night${nights() === 1 ? '' : 's'} · ` +
            'illustrative budget, not a hotel quote';
    }
}

function updateBudgetLabel() {
    budgetValue.textContent = money(budgetSlider.value);
    updateTripBudget();
}

const savedPrefs = store.get('smartPrefs', null);
if (savedPrefs) {
    $('budgetInput').value = savedPrefs.budget;
    $('purposeSelect').value = savedPrefs.purpose;
    $('atmosphereSelect').value = savedPrefs.mood;
    $('amenitySelect').value = savedPrefs.amenity;
    $('roomTypeSelect').value = savedPrefs.roomType;
}

budgetSlider.addEventListener('input', updateBudgetLabel);
updateBudgetLabel();

// Run SmartMatch
$('smartMatchBtn').addEventListener('click', runSmartMatch);

// Account controls
$('getStartedBtn').addEventListener('click', () => {
    state.user ? signOut() : openAuth('register');
});

$('signInBtn').addEventListener('click', () => {
    state.user ? openAccountMenu() : openAuth('signin');
});

$('tripsLink').addEventListener('click', event => {
    event.preventDefault();
    openTrips();
});

// Modal controls
$('modalClose').addEventListener('click', closeModal);

modalBackdrop.addEventListener('click', event => {
    if (event.target === modalBackdrop) {
        closeModal();
    }
});

document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
        closeModal();
        guestPopover.classList.remove('open');
        suggestions.classList.remove('open');
    }
});

// Mobile navigation
$('mobileMenuBtn').addEventListener('click', () => {
    document.querySelector('.main-nav').classList.toggle('open');
});

document.querySelectorAll('.main-nav a').forEach(link => {
    link.addEventListener('click', () => {
        document.querySelector('.main-nav').classList.remove('open');
    });
});
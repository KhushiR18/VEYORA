VEYORA — hotel photo update

Files:
- index.html
- style.css
- script.js
- PHOTO-SOURCES.md

How to run:
1. Keep all files in the same folder.
2. Open index.html in a browser while connected to the internet.
3. The hotel cards now use property-specific room photos from the linked photo sources.

Notes:
- These are remote image URLs, not bundled image files. A few hosts may block direct image loading; a generic fallback photo is configured in that case.
- Hotel names and addresses were updated for the five formerly invented Bengaluru demo listings (Hotel Grand Bee, Treebo Elite 7, Bloom Hotel - Brookefield, Octave Hotel & Spa - JP Nagar, and Lemon Tree Hotel, Electronics City).
- Displayed rates, ratings, and availability remain illustrative demo data, not live booking information.
- See PHOTO-SOURCES.md for source pages and image-rights guidance.

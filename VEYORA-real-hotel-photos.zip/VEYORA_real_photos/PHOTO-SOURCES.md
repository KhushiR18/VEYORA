# VEYORA hotel photo sources

The hotel cards use property-specific room photographs linked from the sources below. These are external image URLs, so the browser needs an internet connection. A generic fallback photo is used only if a source blocks direct image loading.

**Important:** this is a student demonstration. The photo hosts and hotel operators retain their image rights. Before publishing VEYORA publicly or using these images commercially, ask each hotel/operator for permission or use images explicitly licensed for reuse. Demo prices and availability are not live.

| Listing | Photo source / gallery |
|---|---|
| Taj Fort Aguada Resort & Spa, Goa | https://luxuryescapes.com/in/partner/taj-fort-aguada-resort-and-spa-goa/f07ad2b4-a821-4b52-bb14-617fbcebd911 |
| Goa Marriott Resort & Spa | https://www.marriott.com/en-us/hotels/goimc-goa-marriott-resort-and-spa/photos/ |
| Alila Diwa Goa | https://www.hyatt.com/alila-hotels-and-resorts/en-US/goial-alila-diwa-goa/rooms |
| Hyatt Place Goa Candolim | https://www.tripadvisor.co.uk/Hotel_Feature-g297605-d26616793-zft1-Hyatt_Place_Goa_Candolim.html |
| The St. Regis Goa Resort | https://www.cvent.com/venues/goa/hotel/the-st-regis-goa-resort/venue-5938eca4-e431-49fe-a80e-0d447433860f |
| Taj West End, Bengaluru | https://www.tajhotels.com/en-in/hotels/taj-west-end-bengaluru/gallery |
| The Leela Palace Bengaluru | https://www.expedia.ca/Bengaluru-Hotels-The-Leela-Palace-Bengaluru.h851448.Hotel-Information |
| The Taj Mahal Palace, Mumbai | https://www.hotels.com/ho623671776/the-taj-mahal-palace-mumbai-mumbai-india/ |
| Trident, Nariman Point, Mumbai | https://www.makemytrip.com/hotels/trident_nariman_point-details-mumbai.html |
| The Imperial, New Delhi | https://www.theimperialindia.com/accommodations/luxury-suite |
| Rambagh Palace, Jaipur | https://www.easemytrip.com/hotels/rambagh-palace-85854/ |
| Taj Lake Palace, Udaipur | https://www.hoteles.com/en/ho240595/taj-lake-palace-pichola-india/ |
| Grand Hyatt Kochi Bolgatty | https://www.hyatt.com/grand-hyatt/en-US/cokgh-grand-hyatt-kochi-bolgatty/gallery |
| Taj Coromandel, Chennai | https://www.tajhotels.com/en-in/hotels/taj-coromandel-chennai/gallery |
| Taj Falaknuma Palace, Hyderabad | https://www.travelogyindia.com/hotels/taj-falaknuma-palace-hyderabad/ |
| The Oberoi Amarvilas, Agra | https://www.oberoihotels.com/hotels-in-agra-amarvilas-resort/gallery/ |
| Wildflower Hall, Shimla | https://so.city/delhi/article/an-open-air-heated-jacuzzi-with-a-view-of-the-himalayas-wildflower-hall-shimla |
| Span Resort & Spa, Manali | https://spanresorts.com/gallery/ |
| ITC Royal Bengal, Kolkata | https://www.marriott.com/en-us/hotels/cculr-itc-royal-bengal-a-luxury-collection-hotel-kolkata/photos/ |
| Taj Ganges, Varanasi | https://www.tajhotels.com/en-in/hotels/taj-ganges-varanasi/rooms-and-suites |
| ibis Bengaluru City Centre | https://all.accor.com/hotel/6454/index.en.shtml |
| Ginger Bangalore - Inner Ring Road | https://www.gingerhotels.com/hotels/ginger-bangalore-irr/rooms-and-suites |
| The Chancery Pavilion, Bengaluru | https://www.makemytrip.com/hotels/the_chancery_pavilion-details-bangalore.html |
| Hotel Empire International - Church Street, Bengaluru | https://www.agoda.com/en-au/hotel-empire-international-church-street/hotel/bangalore-in.html |
| Hotel Grand Bee, Bengaluru | https://www.hotels.com/ho426286/grand-bee-hotel-bengaluru-india/ |
| Treebo Elite 7, Bengaluru | https://www.easemytrip.com/hotels/treebo-elite-7-near-chinnaswamy-stadium-3500473/ |
| Bloom Hotel - Brookefield, Bengaluru | https://www.lentlo.com/businesses/bloom-hotel-brookefield |
| Octave Hotel & Spa - JP Nagar, Bengaluru | https://www.booking.com/hotel/in/octave-and-spa-jp-nagar.html |
| Lemon Tree Hotel, Electronics City, Bengaluru | https://www.lemontreehotels.com/lemon-tree-hotel/bengaluru/electronics-city-bengaluru/gallery |
